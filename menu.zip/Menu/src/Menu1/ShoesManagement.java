package Menu1;

public class ShoesManagement {

}
