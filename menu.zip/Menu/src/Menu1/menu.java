package Menu1;
import java.util.Scanner;
import java.util.*;
public class menu {

/*
1.입고 (shoes_Plus) -> 1.품목(item), 2.추가(add)
2.출고 (shoes_Minus) -> 1.품목(item), 2.판매(sales)
3.재고 관리(shoes_Stock) -> 1.현재(current), 2.발주량(order), 3.판매량(sales)
*/
	
public static void main(String[] args) {
String shoes_Plus,shoes_Minus,shoes_Stock;

// shoes she = new shoes();
while(true) {
System.out.println("*** 메뉴선택 ***\n");
System.out.println("1. 입고");
System.out.println("2. 출고");
System.out.println("3. 재고 관리");
System.out.println("4. 프로그램 종료");
Scanner sc = new Scanner(System.in);
}
}

public void ShoesManagement(int choice) {
	switch (choice) {
	case 1:
	System.out.println("입고");
		break;
	case 2:
		System.out.println("출고");
		break;
	case 3:
		System.out.println("재고 관리");
		break;
	default:
		System.out.println("1~3에서 선택");
	
	}
}
}