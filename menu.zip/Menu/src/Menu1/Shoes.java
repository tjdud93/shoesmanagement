package Menu1;
import java.util.Scanner;
import java.util.*;
public class Shoes {
public static void main(String[] args) {
System.out.println("*** 메뉴선택 ***\n");
System.out.println("1. 입고");
System.out.println("2. 출고");
System.out.println("3. 재고 관리");
System.out.println("4. 프로그램 종료");
System.out.print("선택>> ");
Scanner sc = new Scanner(System.in);

int num;
num = sc.nextInt();
	}
}
